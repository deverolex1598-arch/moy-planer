package ru.softplanner.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val web=WebView(this); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
  web.webViewClient=WebViewClient(); web.loadUrl("file:///android_asset/index.html"); setContentView(web)
 }
 override fun onBackPressed(){ val w=(window.decorView as? android.view.ViewGroup)?.getChildAt(0) as? WebView
  if(w?.canGoBack()==true) w.goBack() else super.onBackPressed()
 }
}